

array = [];

function myfun() {
		var t = 1;
		//var loadUrl = "http://localhost:8080/NewTrainStatus/TrainStatusServlet?StationCode=SBC&json=true";
		var loadUrl = "file:///media/HDD%20500/Current_Working/Train_Info-Web-App/Working_FolderJson/dep1/train.txt";
        $.ajax({
                  type: "GET",
      	          url: loadUrl,
                  dataType: "json",
                  data: {},
                  success: function (data) {          
                  try {

                        if (data != null) {
                        				  var i = 0;
              	  						  $.each(data, function(key, val){
              	  						  					$.each(val, function(k, v){
                  														if(k =="train_number" || k =="train_name" || k =="scheduled_arrival" )
                  														{
	                 														array.push(v);
	                 													}
                  												});
                  					      });
                  					      display_info();
                  		}
                     }
                  catch (error) {
                     			  window.alert("error!");
                                }
                                },
                                
                 
            });
 
         }
          			 
function display_info(){
			 l = array.length;
    		 var counter = 0;
    		 var order = 0;
   			 for(var i = 0; i<l; i++)
   			 {
   			 	var vl = array[i];
   			 	
           		$("<div class='column'>"+vl+"</div>").appendTo('#display');
    		 }   
    		          				        
                          
		}
