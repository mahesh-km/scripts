#!/bin/sh
# vmc plasma player
# continous playing of ads.mp4
#

tvservice -s
omxplayer --win "0 0 1920 1080"  ads.mp4

