#!/bin/bash

if pgrep searchd | grep "[0-9]" 
then
  donothing=0
else
  cd /home/pi
  python -m SimpleHTTPServer &
fi

while true; do
  echo "capturing screen"
  /home/pi/raspi2png -h 480 -w 640 -p screen.png
  counter="kacantoutsb - "
  title=`date`
  convert screen.png -font Arial -pointsize 20 -background Khaki label:"$counter ${title}" -gravity Center +swap -append screen.jpg

  sleep 60 # sleeping 1 minute
done
