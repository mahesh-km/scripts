#!/bin/sh

pwomxplayer --win "0 0 1280 720" udp://239.0.1.23:1234?buffer_size=1200000B

