#!/bin/sh

pwomxplayer --win "0 20 1080 1440" udp://239.0.1.23:1234?buffer_size=1200000B

